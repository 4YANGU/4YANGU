# StoYangu — My Store, My Hope

StoYangu builds complete online storefronts for Kenyan social-media sellers. Sellers get a store on its own address, share the link in TikTok / Instagram / WhatsApp marketing, and customers browse live products and order through WhatsApp. Owners manage everything from a phone-first dashboard.

**Current pricing (authoritative):** the KES 15,000 store build is fully waived in exchange for a short TikTok tagging StoYangu. Then, at the end of every 30-day upkeep period: **FREE = 0–7 confirmed orders (KES 0)**, **PRO = 8+ confirmed orders (KES 999 upkeep)**.

---

# HOW TO TEST THE APP YOURSELF (plain language)

Take about 15 minutes. Do it once on a computer (desktop) and once on your phone. Everything below should work exactly as described — if anything does not, that is a real problem worth reporting.

## PART 1 — ON A COMPUTER (DESKTOP)

### 1. The marketing page
1. Open the app's home page.
2. Check: the page loads fast, looks polished, and the pricing section says **FREE = 0–7 orders** and **PRO = 8+ orders (KES 999)** in a 30-day period.
3. Click **Apply for a store** (or the apply button) — a form should open asking only for a name and phone number. Submit a test application.
4. You will check that application arrived in the founder dashboard (step 3 below).

### 2. Login
1. Click **Login**.
2. Click **Open founder demo** — it must sign you straight in with **no password**.
3. You should land on the **Founder dashboard**.

### 3. Founder dashboard
1. **Counters:** each store card shows **FREE · x/7 orders** (or PRO · KES 999 when past 7).
2. **Applications:** the test application you submitted appears under Applications. You can change its status (new / contacted / approved).
3. **Power button (turn OFF):**
   - Click the power switch on a store that has orders.
   - Read the confirmation message and accept.
   - The store flips to OFF. **Nothing downloads automatically** (that is correct — downloads are manual now).
   - The store's "latest update" card is cleared.
4. **Archive button (package icon):**
   - Click the package icon on that same store.
   - A window opens showing the archived orders with the date and count.
   - Click **View orders** to see them, and **Download CSV** to download them (only when YOU click it).
5. **Power button (turn ON):**
   - Click the power switch again.
   - It must ask: **restore the saved orders** or **start blank**.
   - Try both choices on different stores and confirm the orders come back (restore) or stay archived (blank).
6. **Client AI prompt:** click **Copy new-client AI prompt** — paste it into a text file and confirm it starts with "Design one extraordinary, completely original storefront for this client." and contains the STORE NAME / LOCATION / WHAT THEY SELL fill-in blocks.

### 4. Manage a store (owner view)
1. On any store card click **Manage store**.
2. Check the order of the page: your **latest update / notification appears ABOVE the Incoming orders list**.
3. Check the header: the store link, **Copy link** button, and a simple **Download Stika** button sit together (no big sticker section anywhere).
4. Click **Download Stika** — a sticker PNG downloads.
5. **Incoming orders:** every order row shows the **photo of the product** that was ordered, the product name, price, choices (colour/size/delivery), the customer's phone number, and a new/done toggle.
6. Toggle an order to **done** and back — it updates instantly.
7. **Products:** click **Add product**, fill in a name, price and photo, save — it appears in the list. Edit it, then delete it.

### 5. The storefront + popup (as a customer)
1. Open a live store (click the store's link, e.g. the Beston Kicks address).
2. The navbar shows the logo, the store's FULL name, and Home / Products / Contact links. On a wide desktop screen the layout is: **logo on the LEFT, menu buttons in the MIDDLE, store name on the RIGHT**.
3. Click **View product** on any product.
4. The popup must show:
   - the product photo with **‹ and › arrows** to move to the next/back photo, plus a clickable strip of ALL the product's photos underneath;
   - **SIZE** and **COLOUR** titles above their choices;
   - a delivery section titled **"Ikufikie aje?"** with Walk in Store / Delivery;
   - choose Delivery, type an address, type a note, tap **Order via WhatsApp**;
   - the phone step shows the sentence **"Press confirm, WhatsApp will open with your order ready — Then hit send and we will reply to you shortly."** and the button says only **Confirm**;
   - WhatsApp opens with a message shaped like:
     `Hi STORE! I want to order PRODUCT (KSh X) in size M, colour Green.`
     `Fulfilment: Delivery`
     `Address: Nairobi`
     `Customer note: Harakisha`
     `Please confirm availability.`
   - Confirm the word "Delivery" is NOT repeated on the address line.

### 6. AI & search info
1. Open `/llms.txt`, `/ai.txt`, `/sitemap.xml` and `/catalog.json` in the browser.
2. Each must load and describe StoYangu with the **7-order FREE threshold** and current contact details — no old pricing anywhere.

## PART 2 — ON YOUR PHONE

1. **Open the same app link in your phone browser.**
2. **Marketing page:** everything stacks neatly, nothing overlaps, buttons are easy to tap.
3. **Login:** tap Login → **Open founder demo** → the founder dashboard loads. The navigation moves to a bottom bar; all sections still work.
4. **Storefront:** open a store. The mobile navbar shows the logo on the left with the FULL store name beside it and the menu links neatly underneath.
5. **Popup:** tap a product — the popup opens fully, the ‹ › arrows and photo strip work, titles (SIZE / COLOUR / **Ikufikie aje?**) are visible, and the Confirm flow opens WhatsApp with the correctly shaped message.
6. **Manage store:** open Manage store — latest update above orders, order photos visible, Download Stika next to Copy link.
7. **Install as an app (owner accounts):** in the owner dashboard use **Install app** / Add to Home Screen, then open it from the home screen and confirm it signs you back in.

## PART 3 — QUICK SECURITY CHECKS

1. Open a dashboard page in a **private/incognito window** without logging in — you must be redirected to Login (nothing leaks).
2. Try opening `/api/dashboard` directly in the browser without logging in — it must refuse with an "Unauthorized" / login message, never data.
3. On the live production domain, the demo founder login must NOT grant dashboard access (demo works only on preview/test domains).
4. Browser console on any storefront: no tracker messages, no element-picker messages, no unknown scripts.

If every step above behaves as described, the app is working exactly as built.
