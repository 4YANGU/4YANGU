/**
 * Beston Kicks — StoYangu skin script
 * Local DOM only: nav anchors, mobile drawer, category filters, spec chips.
 * Forbidden: fetch, XHR, eval, external scripts, cookies, storage, APIs.
 */
(function () {
  'use strict';

  function qs(sel, root) {
    return (root || document).querySelector(sel);
  }

  function qsa(sel, root) {
    return Array.prototype.slice.call((root || document).querySelectorAll(sel));
  }

  /* ---------- Mobile nav drawer ---------- */
  function initNavDrawer() {
    var toggle = qs('[data-nav-toggle]');
    var drawer = qs('[data-nav-drawer]');
    if (!toggle || !drawer) return;

    function setOpen(open) {
      if (open) {
        drawer.removeAttribute('hidden');
      } else {
        drawer.setAttribute('hidden', '');
      }
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
      toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    }

    toggle.addEventListener('click', function () {
      var open = drawer.hasAttribute('hidden');
      setOpen(open);
    });

    qsa('[data-nav-link]', drawer).forEach(function (link) {
      link.addEventListener('click', function () {
        setOpen(false);
      });
    });
  }

  /* ---------- Smooth section anchors + active link ---------- */
  function initNavAnchors() {
    var header = qs('[data-sty-nav]');
    var links = qsa('a[data-nav-link][href^="#"]');

    links.forEach(function (link) {
      link.addEventListener('click', function (e) {
        var id = link.getAttribute('href');
        if (!id || id.charAt(0) !== '#') return;
        var target = qs(id);
        if (!target) return;
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        if (history.replaceState) {
          history.replaceState(null, '', id);
        }
      });
    });

    // Sticky header scrolled state
    if (header) {
      var onScroll = function () {
        if (window.scrollY > 10) header.classList.add('is-scrolled');
        else header.classList.remove('is-scrolled');
      };
      onScroll();
      window.addEventListener('scroll', onScroll, { passive: true });
    }

    // Active section highlighting via IntersectionObserver (DOM-only)
    var sections = qsa('[data-section]');
    if (!sections.length || !('IntersectionObserver' in window)) return;

    var navLinks = qsa('.nav-link[href^="#"], .nav-drawer-link[href^="#"]');

    var obs = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (!entry.isIntersecting) return;
          var id = entry.target.id;
          navLinks.forEach(function (a) {
            var href = a.getAttribute('href') || '';
            var active = href === '#' + id;
            if (active) a.classList.add('is-active');
            else a.classList.remove('is-active');
          });
        });
      },
      { rootMargin: '-40% 0px -45% 0px', threshold: 0 }
    );

    sections.forEach(function (sec) {
      obs.observe(sec);
    });
  }

  /* ---------- Category filter chips (show/hide product cards) ---------- */
  function initCategoryFilters() {
    var chipHost = qs('[data-sty-chips]');
    var grid = qs('[data-products-root]') || qs('[data-sty-products]');
    var empty = qs('[data-products-empty]');
    if (!chipHost || !grid) return;

    function cards() {
      return qsa('.product-card', grid);
    }

    function normalize(value) {
      return String(value || '')
        .toLowerCase()
        .replace(/&amp;/g, 'and')
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-|-$/g, '');
    }

    function chipValue(el) {
      return (
        el.getAttribute('data-filter') ||
        el.getAttribute('data-category') ||
        el.getAttribute('data-slug') ||
        el.textContent ||
        ''
      );
    }

    function setActiveChip(activeEl) {
      qsa('[data-filter], .chip, button, a, span', chipHost).forEach(function (el) {
        // Only treat direct interactive/chip-like children as filter controls
        if (el.parentElement !== chipHost && !el.hasAttribute('data-filter')) return;
        var on = el === activeEl;
        if (on) el.classList.add('is-active');
        else el.classList.remove('is-active');
        if (el.setAttribute) {
          if (el.getAttribute('role') === 'tab') {
            el.setAttribute('aria-selected', on ? 'true' : 'false');
          }
        }
      });
    }

    function applyFilter(raw) {
      var key = normalize(raw);
      var list = cards();
      var visible = 0;

      list.forEach(function (card) {
        var cat = normalize(
          card.getAttribute('data-category') ||
            (qs('.product-card-cat', card) && qs('.product-card-cat', card).textContent) ||
            ''
        );
        var show = !key || key === 'all' || key === 'all-kicks' || cat === key || cat.indexOf(key) !== -1 || key.indexOf(cat) !== -1;
        if (show) {
          card.classList.remove('is-hidden');
          visible += 1;
        } else {
          card.classList.add('is-hidden');
        }
      });

      if (empty) {
        if (visible === 0 && list.length > 0) empty.removeAttribute('hidden');
        else empty.setAttribute('hidden', '');
      }
    }

    chipHost.addEventListener('click', function (e) {
      var t = e.target;
      if (!t) return;
      // Climb to a chip-like control inside the chips row
      var el = t;
      while (el && el !== chipHost) {
        if (
          el.hasAttribute('data-filter') ||
          el.classList.contains('chip') ||
          el.tagName === 'BUTTON' ||
          (el.tagName === 'A' && el.parentElement === chipHost) ||
          (el.parentElement === chipHost && el.getAttribute('role') === 'tab')
        ) {
          break;
        }
        el = el.parentElement;
      }
      if (!el || el === chipHost) return;

      // Allow real navigation only if it's an external/ whitelisted order link — chips stay local
      if (el.tagName === 'A' && el.getAttribute('href') && el.getAttribute('href').charAt(0) !== '#') {
        // If host stamped chips as links to #products filters, still intercept hash-only
        return;
      }
      if (el.tagName === 'A') e.preventDefault();

      setActiveChip(el);
      applyFilter(chipValue(el));
    });
  }

  /* ---------- Spec chips (sizes / colours) — local toggle only ---------- */
  function initSpecChips() {
    qsa('[data-spec-chips]').forEach(function (group) {
      // Product-card size lists are display-only
      if (group.classList.contains('product-card-sizes')) return;

      group.addEventListener('click', function (e) {
        var t = e.target;
        if (!t) return;
        var chip = t;
        while (chip && chip !== group) {
          if (
            chip.classList.contains('spec-chip') ||
            chip.hasAttribute('data-size') ||
            chip.hasAttribute('data-color') ||
            chip.getAttribute('role') === 'listitem' ||
            chip.tagName === 'BUTTON' ||
            (chip.parentElement === group && chip.tagName !== 'SCRIPT')
          ) {
            break;
          }
          chip = chip.parentElement;
        }
        if (!chip || chip === group) return;
        if (chip.tagName === 'A') e.preventDefault();

        qsa(':scope > *', group).forEach(function (el) {
          el.classList.remove('is-active');
          if (el.hasAttribute('aria-pressed')) el.setAttribute('aria-pressed', 'false');
        });
        chip.classList.add('is-active');
        if (chip.hasAttribute('aria-pressed') || chip.tagName === 'BUTTON') {
          chip.setAttribute('aria-pressed', 'true');
        }
      });
    });
  }

  function boot() {
    initNavDrawer();
    initNavAnchors();
    initCategoryFilters();
    initSpecChips();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
